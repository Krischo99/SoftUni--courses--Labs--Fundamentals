package Fundamentals.ClassesAndObjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Student> students = new ArrayList<>();

        while (true) {

            String input = scanner.nextLine();

            if (input.equals("end")) {
                break;
            }

            String[] studentInfo = input.split(" ");
            int studentAge = Integer.parseInt(studentInfo[2]);
            Student student = new Student(studentInfo[0], studentInfo[1], studentAge, studentInfo[3]);

            students.add(student);
        }

        String cityFilter = scanner.nextLine();

        for (Student currentStudent : students) {

            if (currentStudent.getHomeTown().equals(cityFilter)) {

                System.out.println(currentStudent.printStudentInfo());
            }
        }
    }
}
